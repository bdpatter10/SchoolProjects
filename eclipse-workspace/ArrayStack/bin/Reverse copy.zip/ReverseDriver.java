/*Name: Blake Patterson
 * Date: June 26 2018
 * Description: Driver that gets user input and calls backwards method
 *  to reverse the order
 */
import jsjf.exceptions.*;   
import jsjf.ArrayStack;
import jsjf.StackADT;
import java.util.*;


public class ReverseDriver 
{
	public static void main(String[]args)
	{
	String message = "Stack";
	String command = "";
	int index = 0;
	String[] strings = new String[100];
	EmptyCollectionException empty = new EmptyCollectionException(message);
	Reverse<String> r = new Reverse<String>();
	Reverse<Integer> num = new Reverse<Integer>();
	ArrayStack<String> input = new ArrayStack<String>();
	//get strings from user
	while(!command.equals("DONE"))
	{
	
		Scanner scan = new Scanner(System.in);
		System.out.println("---------What is your next String?--------- "
				+ "\nIf done type: DONE ");
		command = scan.nextLine();
		
		if(!command.equals("DONE"))
			strings[index] = command + " ";
		
		index++;
	}
	//push each string from the array strings
	for(int i = 0; i < index - 1; i++)
	{
		input.push(strings[i]);
	}
	//print the inputs in reverse order
	System.out.println("Your Strings in reverse order: ");
	System.out.println(r.backwards(input));
	
	//original test case
	int b[];
	b = new int[]{0, 1, 2, 3, 4, 5};
	
	/*String a[];
	a = new String[]{"man", "boy", "c", "d","e", "f"};*/
	
	ArrayStack<Integer> flip = new ArrayStack<Integer>();
	
	int length = b.length;
	
	for(int i = 0; i < length; i++)
	{
		flip.push(b[i]);
		
	}
	
	System.out.println("the original order of integers: " + flip.toString());
	System.out.println("the integers in reverse order " 
			+ num.backwards(flip));	
	
	}
}
