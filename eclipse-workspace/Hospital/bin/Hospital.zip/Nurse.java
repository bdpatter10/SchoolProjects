/*Name: Blake Patterson     
 * Date: June 11 2018
 * Program Description: Nurse class
 */
public class Nurse extends HospitalEmployee {
	
	public void getNurse()
	{
		getMessage();
		System.out.println("I am a Nurse!");
	}

}
