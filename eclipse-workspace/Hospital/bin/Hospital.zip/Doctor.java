/*Name: Blake Patterson     
 * Date: June 11 2018
 * Program Description:Doctor class
 */
public class Doctor extends HospitalEmployee 
{
	
	public void getDoctor()
	{
		getMessage();
		System.out.println("I am a Doctor!");
		
	}

}
