/*Name: Blake Patterson     
 * Date: June 11 2018
 * Program Description:Surgeon class
 */
public class Surgeon extends Doctor 
{

	public void getSurgeon()
	{
		
		getDoctor();
		System.out.println("I am a Surgeon!");
	}
}
