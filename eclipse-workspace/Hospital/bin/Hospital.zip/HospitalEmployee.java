/*Name: Blake Patterson     
 * Date: June 11 2018
 * Program Description:Hospital Employee class
 */
public class HospitalEmployee {
	
	public void getMessage() 
	{
		System.out.println("I work at the hospital");
		
	}

}
