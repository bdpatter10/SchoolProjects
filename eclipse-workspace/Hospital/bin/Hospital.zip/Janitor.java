/*Name: Blake Patterson     
 * Date: June 11 2018
 * Program Description:Janitor class
 */
public class Janitor extends HospitalEmployee 
{
	public void getJanitor()
	{
		getMessage();
		System.out.println("I am a Janitor!");
	}

}
