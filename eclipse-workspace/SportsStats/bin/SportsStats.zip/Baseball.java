/*Name: Blake Patterson
 *Date: June 11 2018
 *Description: Baseball Class
 */
public class Baseball extends AllSports
{
	protected int hits;
	protected int runs;
	protected int wins;

	public void setHits(int hits) 
	{
		this.hits += hits;
	}
	
	public void setRuns(int runs) 
	{
		this.runs += runs;
	}
	

	
}
