/*Name: Blake Patterson
 *Date: June 11 2018
 *Description: All Sports Class
 */
public class AllSports {
	
	protected int wins;
	protected int loses;

	public int getWins() 
	{
		return wins;
	}

	public void setWins(int wins) 
	{
		this.wins += wins;
	}

	public int getLoses() 
	{
		return loses;
	}

	public void setLoses(int loses) 
	{
		this.loses += loses;
	}
	
	

}
