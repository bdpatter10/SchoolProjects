
public class Dad implements Speaker
{
	public void speak()
	{
		System.out.println("Do whatever you want!");
	}
	
	public void announce(String str)
	{
		System.out.println(str);
	}
}
