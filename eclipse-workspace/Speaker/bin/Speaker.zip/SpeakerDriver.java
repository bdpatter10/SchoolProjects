
public class SpeakerDriver 
{
	public static void main(String[] args)
	{
		Speaker current = new Mom();
		System.out.print("Mom says to ");
		current.speak();
		
		current = new Dad();
		current.speak();
		
		current = new Child();
		current.speak();
		
	}

}
