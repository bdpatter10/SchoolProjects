
public class Mom implements Speaker
{

	public void speak()
	{
		System.out.println("Do your homework!");
	}
	
	public void announce(String str)
	{
		System.out.println(str);
	}
}
