
public class Child implements Speaker
{
	public void speak()
	{
		System.out.println("I don't want to!");
	}
	
	public void announce(String str)
	{
		System.out.println(str);
	}
}
